﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{//برنامه نویس بهروز نوبهار nobahar.behrooz@gmail.com
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int harekat = 1;
        int _1x;
        int _2x;
        int _3x;
        int _4x;
        int _5x;
        int _6x;
        int _7x;
        int _8x;
        int _9x;
        int _1y;
        int _2y;
        int _3y;
        int _4y;
        int _5y;
        int _6y;
        int _7y;
        int _8y;
        int _9y;
        private void hiorestik()
        {
            str();
            int hiorestick =8;
            if (_1x == 1 && _1y == 3)
                hiorestick--;
            if (_2x == 90 && _2y == 3)
                hiorestick--;
            if (_3x == 180 && _3y == 3)
                hiorestick--;
            if (_4x == 1 && _4y == 73)
                hiorestick--;
            if (_5x == 90 && _5y == 73)
                hiorestick--;
            if (_6x == 180 && _6y == 73)
                hiorestick--;
            if (_7x == 1 && _7y == 143)
                hiorestick--;
            if (_8x == 90 && _8y == 143)
                hiorestick--;

            MessageBox.Show(" ما احتمال می دهیم که این بازی با حداقل"+ hiorestick.ToString() + "حرکت قابل حل می باشد","احتمال");

        }
        //private void fazaehalat()
        //{
        //    int[] ex;
        //    int[] un;
        //    int n = ex[1];
        //    un[]= -un - n;
        //    if (n == gol()) { gol(); };
        //    if
        //}
        private void str()
        {
            _1x = btn_1.Location.X;
            _1y = btn_1.Location.Y;
            _2x = btn_2.Location.X;
            _2y = btn_2.Location.Y;
            _3x = btn_3.Location.X;
            _3y = btn_3.Location.Y;
            _4x = btn_4.Location.X;
            _4y = btn_4.Location.Y;
            _5x = btn_5.Location.X;
            _5y = btn_5.Location.Y;
            _6x = btn_6.Location.X;
            _6y = btn_6.Location.Y;
            _7x = btn_7.Location.X;
            _7y = btn_7.Location.Y;
            _8x = btn_8.Location.X;
            _8y = btn_8.Location.Y;
            _9x = btn_free.Location.X;
            _9y = btn_free.Location.Y;
            label1.Text = _1x.ToString();
            label2.Text = _1y.ToString();
            label3.Text = _2x.ToString();
            label4.Text = _2y.ToString();
            label5.Text = _3x.ToString();
            label6.Text = _3y.ToString();
            label7.Text = _4x.ToString();
            label8.Text = _4y.ToString();
            label9.Text = _5x.ToString();
            label10.Text = _5y.ToString();
            label11.Text = _6x.ToString();
            label12.Text = _6y.ToString();
            label13.Text = _7x.ToString();
            label14.Text = _7y.ToString();
            label15.Text = _8x.ToString();
            label16.Text = _8y.ToString();
            label17.Text = _9x.ToString();
            label18.Text = _9y.ToString();
        }
        private void gol()
        {
            if (_1x == 1 && _1y == 3)
            if (_2x == 90 && _2y == 3)
            if (_3x == 180 && _3y == 3)
            if (_4x == 1 && _4y == 73)
            if (_5x == 90 && _5y == 73)
            if (_6x == 180 && _6y == 73)
            if (_7x == 1 && _7y == 143)
            if (_8x == 90 && _8y == 143)   
            { tmr_time.Stop(); MessageBox.Show("you win", ":)");  }


        }
        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("برنامه نویس بهروز نوبهار \n nobahar.behrooz@gmail.com","programmer");
            str();
        }
        private void btn_1_Click(object sender, EventArgs e)
        {

            label22.Text = harekat.ToString();
            if (_1y + 70 == _9y && _1x == _9x/*حرکت به بالا*/ || _1y - 70 == _9y && _1x == _9x/*حرکت به پایین*/)
            {
                btn_1.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_1x, _1y);
                harekat++;
            }
            if (_1x + 90 == _9x && _1y == _9y/*حرکت به راست*/|| _1x - 90 == _9x && _1y == _9y/*حرکت به چپ*/)
            {
                btn_1.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_1x, _1y);
                harekat++;
            }
            if (_1x - 90 == 0 && _1y == _9y/*حرکت به چپ*/|| _1y - 70 == 0 && _1y == _9y/*حرکت به راست*/)
            {
                btn_1.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_1x, _1y);
                harekat++;
            }
            if (_1x + 89 == 90 && _1y == _9y && _9x != 180/* به چپ*/|| _1y + 69 == 70 && _1y == _9y/*حرکت به راست*/)
            {
                btn_1.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_1x, _1y);
                harekat++;
            }
            str();
            gol();
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            label22.Text = harekat.ToString();
            if (_6y + 70 == _9y && _6x == _9x/*حرکت به بالا*/ || _6y - 70 == _9y && _6x == _9x/*حرکت به پایین*/)
            {
                btn_6.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_6x, _6y);
                harekat++;
            }
            if (_6x + 90 == _9x && _6y == _9y/*حرکت به راست*/|| _6x - 90 == _9x && _6y == _9y/*حرکت به چپ*/)
            {
                btn_6.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_6x, _6y);
                harekat++;
            }
            if (_6x - 90 == 0 && _6y == _9y/*حرکت به چپ*/|| _6y - 70 == 0 && _6y == _9y/*حرکت به راست*/)
            {
                btn_6.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_6x, _6y);
                harekat++;
            }
            if (_6x + 89 == 90 && _6y == _9y && _9x != 180/* به چپ*/|| _6y + 69 == 70 && _6y == _9y/*حرکت به راست*/)
            {
                btn_6.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_6x, _6y);
                harekat++;
            }
            str();
            gol();
        }

        private void btn_2_Click(object sender, EventArgs e)
        {

            label22.Text = harekat.ToString();
            if (_2y + 70 == _9y && _2x == _9x/*حرکت به بالا*/ || _2y - 70 == _9y && _2x == _9x/*حرکت به پایین*/)
            {
                btn_2.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_2x, _2y);
                harekat++;
            }
            if (_2x + 90 == _9x && _2y == _9y/*حرکت به راست*/|| _2x - 90 == _9x && _2y == _9y/*حرکت به چپ*/)
            {
                btn_2.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_2x, _2y);
                harekat++;
            }
            if (_2x - 90 == 0 && _2y == _9y/*حرکت به چپ*/|| _2y - 70 == 0 && _2y == _9y/*حرکت به راست*/)
            {
                btn_2.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_2x, _2y);
                harekat++;
            }
            if (_2x + 89 == 90 && _2y == _9y && _9x != 180/* به چپ*/|| _2y + 69 == 70 && _2y == _9y/*حرکت به راست*/)
            {
                btn_2.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_2x, _2y);
                harekat++;
            }
            str();
            gol();

        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            label22.Text = harekat.ToString();
            if (_3y + 70 == _9y && _3x == _9x/*حرکت به بالا*/ || _3y - 70 == _9y && _3x == _9x/*حرکت به پایین*/)
            {
                btn_3.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_3x, _3y);
                harekat++;
            }
            if (_3x + 90 == _9x && _3y == _9y/*حرکت به راست*/|| _3x - 90 == _9x && _3y == _9y/*حرکت به چپ*/)
            {
                btn_3.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_3x, _3y);
                harekat++;
            }
            if (_3x - 90 == 0 && _3y == _9y/*حرکت به چپ*/|| _3y - 70 == 0 && _3y == _9y/*حرکت به راست*/)
            {
                btn_3.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_3x, _3y);
                harekat++;
            }
            if (_3x + 89 == 90 && _3y == _9y && _9x != 180/* به چپ*/|| _3y + 69 == 70 && _3y == _9y/*حرکت به راست*/)
            {
                btn_3.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_3x, _3y);
                harekat++;
            }
            str();
            gol();
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            label22.Text = harekat.ToString();
            if (_4y + 70 == _9y && _4x == _9x/*حرکت به بالا*/ || _4y - 70 == _9y && _4x == _9x/*حرکت به پایین*/)
            {
                btn_4.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_4x, _4y);
                harekat++;
            }
            if (_4x + 90 == _9x && _4y == _9y/*حرکت به راست*/|| _4x - 90 == _9x && _4y == _9y/*حرکت به چپ*/)
            {
                btn_4.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_4x, _4y);
                harekat++;
            }
            if (_4x - 90 == 0 && _4y == _9y/*حرکت به چپ*/|| _4y - 70 == 0 && _4y == _9y/*حرکت به راست*/)
            {
                btn_4.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_4x, _4y);
                harekat++;
            }
            if (_4x + 89 == 90 && _4y == _9y && _9x != 180/* به چپ*/|| _4y + 69 == 70 && _4y == _9y/*حرکت به راست*/)
            {
                btn_4.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_4x, _4y);
                harekat++;
            }
            str();
            gol();

        }

        private void btn_5_Click(object sender, EventArgs e)
        {

            label22.Text = harekat.ToString();
            if (_5y + 70 == _9y && _5x == _9x/*حرکت به بالا*/ || _5y - 70 == _9y && _5x == _9x/*حرکت به پایین*/)
            {
                btn_5.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_5x, _5y);
                harekat++;
            }
            if (_5x + 90 == _9x && _5y == _9y/*حرکت به راست*/|| _5x - 90 == _9x && _5y == _9y/*حرکت به چپ*/)
            {
                btn_5.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_5x, _5y);
                harekat++;
            }
            if (_5x - 90 == 0 && _5y == _9y/*حرکت به چپ*/|| _5y - 70 == 0 && _5y == _9y/*حرکت به راست*/)
            {
                btn_5.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_5x, _5y);
                harekat++;
            }
            if (_5x + 89 == 90 && _5y == _9y && _9x != 180/* به چپ*/|| _5y + 69 == 70 && _5y == _9y/*حرکت به راست*/)
            {
                btn_5.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_5x, _5y);
                harekat++;
            }
            str();
            gol();

        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            label22.Text = harekat.ToString();
            if (_7y + 70 == _9y && _7x == _9x/*حرکت به بالا*/ || _7y - 70 == _9y && _7x == _9x/*حرکت به پایین*/)
            {
                btn_7.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_7x, _7y);
                harekat++;
            }
            if (_7x + 90 == _9x && _7y == _9y/*حرکت به راست*/|| _7x - 90 == _9x && _7y == _9y/*حرکت به چپ*/)
            {
                btn_7.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_7x, _7y);
                harekat++;
            }
            if (_7x - 90 == 0 && _7y == _9y/*حرکت به چپ*/|| _7y - 70 == 0 && _7y == _9y/*حرکت به راست*/)
            {
                btn_7.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_7x, _7y);
                harekat++;
            }
            if (_7x + 89 == 90 && _7y == _9y && _9x != 180/* به چپ*/|| _7y + 69 == 70 && _7y == _9y/*حرکت به راست*/)
            {
                btn_7.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_7x, _7y);
                harekat++;
            }
            str();
            gol();

        }

        private void btn_8_Click(object sender, EventArgs e)
        {

            label22.Text = harekat.ToString();
            if (_8y + 70 == _9y && _8x == _9x/*حرکت به بالا*/ || _8y - 70 == _9y && _8x == _9x/*حرکت به پایین*/)
            {
                btn_8.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_8x, _8y);
                harekat++;
            }
            if (_8x + 90 == _9x && _8y == _9y/*حرکت به راست*/|| _8x - 90 == _9x && _8y == _9y/*حرکت به چپ*/)
            {
                btn_8.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_8x, _8y);
                harekat++;
            }
            if (_8x - 90 == 0 && _8y == _9y/*حرکت به چپ*/|| _8y - 70 == 0 && _8y == _9y/*حرکت به راست*/)
            {
                btn_8.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_8x, _8y);
                harekat++;
            }
            if (_8x + 89 == 90 && _8y == _9y && _9x != 180/* به چپ*/|| _8y + 69 == 70 && _8y == _9y/*حرکت به راست*/)
            {
                btn_8.Location = new Point(_9x, _9y);
                btn_free.Location = new Point(_8x, _8y);
                harekat++;
            }
            str();
            gol();

        }

        private void btn_free_Click(object sender, EventArgs e)
        {
        }



        private void btn_restart_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btn_random_mode_Click(object sender, EventArgs e)
        {
            harekat = 1;
            label22.ResetText();
            int _rd1,_rd2,_rd3,_rd4,_rd5,_rd6,_rd7,_rd8,_rd9;
            Random rd = new Random();
            _rd1 = rd.Next(0,9);
            do { _rd2 = rd.Next(0,9); }
            while (_rd2 == _rd1);
            do { _rd3 = rd.Next(0,9); }
            while (_rd3 == _rd1 || _rd3 == _rd2);
            do { _rd4 = rd.Next(0,9); }
            while (_rd4 == _rd1 || _rd4 == _rd2 || _rd4 == _rd3 );
            do { _rd5 = rd.Next(0,9); }
            while (_rd5 == _rd1 || _rd5 == _rd2 || _rd5 == _rd3 || _rd5 == _rd4);
            do { _rd6 = rd.Next(0,9); }
            while (_rd6 == _rd1 || _rd6 == _rd2 || _rd6 == _rd3 || _rd6 == _rd4 || _rd6 == _rd5 );
            do { _rd7 = rd.Next(0,9); }
            while (_rd7 == _rd1 || _rd7 == _rd2 || _rd7 == _rd3 || _rd7 == _rd4 || _rd7 == _rd5 || _rd7 == _rd6);
            do { _rd8 = rd.Next(0,9); }
            while (_rd8 == _rd1 || _rd8 == _rd2 || _rd8 == _rd3 || _rd8 == _rd4 || _rd8 == _rd5 || _rd8 == _rd6 || _rd8 == _rd7  );
            do { _rd9 = rd.Next(0, 9); }
            while (_rd9 == _rd1 || _rd9 == _rd2 || _rd9 == _rd3 || _rd9 == _rd4 || _rd9 == _rd5 || _rd9 == _rd6 || _rd9 == _rd7 || _rd9 == _rd8);
            // if (_rd1 == 1 || _rd2 == 1 || _rd3 == 1 || _rd4 == 1 || _rd5 == 1 || _rd6 == 1 || _rd7 == 1 || _rd8 == 1)
            //    _rd9 = 1;
            //else if (_rd1 == 2 || _rd2 != 2 || _rd3 == 2 || _rd4 == 2 || _rd5 == 2 || _rd6 == 2 || _rd7 == 2 || _rd8 == 2)
            //    _rd9 = 2;
            //else if (_rd1 == 3 || _rd2 == 3 || _rd3 == 3 || _rd4 == 3 || _rd5 == 3 || _rd6 == 3 || _rd7 == 3 || _rd8 == 3)
            //    _rd9 = 3;
            //else if (_rd1 == 4 || _rd2== 4 || _rd3 == 4 || _rd4 == 4 || _rd5 == 4 || _rd6 == 4 || _rd7 == 4 || _rd8 == 4)
            //    _rd9 = 4;
            //else if (_rd1 == 5 || _rd2 == 5 || _rd3 == 5 || _rd4 == 5 || _rd5 == 5 || _rd6 == 5 || _rd7 == 5 || _rd8 == 5)
            //    _rd9 = 5;
            //else if (_rd1 == 6 || _rd2 == 6 || _rd3== 6 || _rd4 == 6 || _rd5 == 6 || _rd6 == 6 || _rd7 == 6 || _rd8 == 6)
            //    _rd9 = 6;
            //else if (_rd1 == 7 || _rd2 == 7 || _rd3 == 7 || _rd4 == 7 || _rd5 == 7 || _rd6 == 7 || _rd7 == 7 || _rd8 == 7)
            //    _rd9 = 7;
            //else if (_rd1 == 8 || _rd2 != 8 || _rd3 == 8 || _rd4 == 8 || _rd5 == 8 || _rd6 == 8 || _rd7 == 8 || _rd8 == 8)
            //    _rd9 = 8;
            //else if (_rd1 == 9|| _rd2 != 9 || _rd3 == 9 || _rd4 == 9 || _rd5 == 9 || _rd6 == 9 || _rd7 == 9 || _rd8 == 9)
            //    _rd9 = 9;
            //else _rd9 = 0;

            switch (_rd1)
            {
                case 0:
                   btn_1.Location = new Point(1,3); 
                   break;
                case 1:
                    btn_1.Location = new Point(90,3);
                    break;
                case 2:
                    btn_1.Location = new Point(180,3);
                    break;
                case 3:
                    btn_1.Location = new Point(1,73);
                    break;
                case 4:
                    btn_1.Location = new Point(90,73);
                    break;
                case 5:
                    btn_1.Location = new Point(180,73);
                    break;
                case 6:
                    btn_1.Location = new Point(1, 143);
                    break;
                case 7:
                    btn_1.Location = new Point(90, 143);
                    break;
                case 8:
                    btn_1.Location = new Point(180, 143);
                    break;
                default:
                    btn_1.Location = new Point(1, 3);
                    break;
            }
            switch (_rd2)
            {
                case 0:
                    btn_2.Location = new Point(1, 3);
                    break;
                case 1:
                    btn_2.Location = new Point(90, 3);
                    break;
                case 2:
                    btn_2.Location = new Point(180, 3);
                    break;
                case 3:
                    btn_2.Location = new Point(1, 73);
                    break;
                case 4:
                    btn_2.Location = new Point(90, 73);
                    break;
                case 5:
                    btn_2.Location = new Point(180, 73);
                    break;
                case 6:
                    btn_2.Location = new Point(1, 143);
                    break;
                case 7:
                    btn_2.Location = new Point(90, 143);
                    break;
                case 8:
                    btn_2.Location = new Point(180, 143);
                    break;
                default:
                    btn_2.Location = new Point(90, 3);
                    break;
            }
            switch (_rd3)
            {
                case 0:
                    btn_3.Location = new Point(1, 3);
                    break;
                case 1:
                    btn_3.Location = new Point(90, 3);
                    break;
                case 2:
                    btn_3.Location = new Point(180, 3);
                    break;
                case 3:
                    btn_3.Location = new Point(1, 73);
                    break;
                case 4:
                    btn_3.Location = new Point(90, 73);
                    break;
                case 5:
                    btn_3.Location = new Point(180, 73);
                    break;
                case 6:
                    btn_3.Location = new Point(1, 143);
                    break;
                case 7:
                    btn_3.Location = new Point(90, 143);
                    break;
                case 8:
                    btn_3.Location = new Point(180, 143);
                    break;
                default:
                    btn_3.Location = new Point(180, 3);
                    break;
            }
            switch (_rd4)
            {
                case 0:
                    btn_4.Location = new Point(1, 3);
                    break;
                case 1:
                    btn_4.Location = new Point(90, 3);
                    break;
                case 2:
                    btn_4.Location = new Point(180,3);
                    break;
                case 3:
                    btn_4.Location = new Point(1,73);
                    break;
                case 4:
                    btn_4.Location = new Point(90,73);
                    break;
                case 5:
                    btn_4.Location = new Point(180,73);
                    break;
                case 6:
                    btn_4.Location = new Point(1,143);
                    break;
                case 7:
                    btn_4.Location = new Point(90,143);
                    break;
                case 8:
                    btn_4.Location = new Point(180,143);
                    break;
                default:
                    btn_4.Location = new Point(1,73);
                    break;
            }
            switch (_rd5)
            {
                case 0:
                    btn_5.Location = new Point(1,3);
                    break;
                case 1:
                    btn_5.Location = new Point(90,3);
                    break;
                case 2:
                    btn_5.Location = new Point(180,3);
                    break;
                case 3:
                    btn_5.Location = new Point(1,73);
                    break;
                case 4:
                    btn_5.Location = new Point(90,73);
                    break;
                case 5:
                    btn_5.Location = new Point(180,73);
                    break;
                case 6:
                    btn_5.Location = new Point(1,143);
                    break;
                case 7:
                    btn_5.Location = new Point(90,143);
                    break;
                case 8:
                    btn_5.Location = new Point(180,143);
                    break;
                default:
                    btn_5.Location = new Point(90,73);
                    break;
            }
            switch (_rd6)
            {
                case 0:
                    btn_6.Location = new Point(1,3);
                    break;
                case 1:
                    btn_6.Location = new Point(90,3);
                    break;
                case 2:
                    btn_6.Location = new Point(180,3);
                    break;
                case 3:
                    btn_6.Location = new Point(1,73);
                    break;
                case 4:
                    btn_6.Location = new Point(90,73);
                    break;
                case 5:
                    btn_6.Location = new Point(180,73);
                    break;
                case 6:
                    btn_6.Location = new Point(1,143);
                    break;
                case 7:
                    btn_6.Location = new Point(90,143);
                    break;
                case 8:
                    btn_6.Location = new Point(180,143);
                    break;
                default:
                    btn_6.Location = new Point(180,73);
                    break;
            }
            switch (_rd7)
            {
                case 0:
                    btn_7.Location = new Point(1,3);
                    break;
                case 1:
                    btn_7.Location = new Point(90,3);
                    break;
                case 2:
                    btn_7.Location = new Point(180,3);
                    break;
                case 3:
                    btn_7.Location = new Point(1,73);
                    break;
                case 4:
                    btn_7.Location = new Point(90,73);
                    break;
                case 5:
                    btn_7.Location = new Point(180,73);
                    break;
                case 6:
                    btn_7.Location = new Point(1,143);
                    break;
                case 7:
                    btn_7.Location = new Point(90,143);
                    break;
                case 8:
                    btn_7.Location = new Point(180, 143);
                    break;
                default:
                    btn_7.Location = new Point(1,143);
                    break;
            }
            switch (_rd8)
            {
                case 0:
                    btn_8.Location = new Point(1,3);
                    break;
                case 1:
                    btn_8.Location = new Point(90,3);
                    break;
                case 2:
                    btn_8.Location = new Point(180,3);
                    break;
                case 3:
                    btn_8.Location = new Point(1,73);
                    break;
                case 4:
                    btn_8.Location = new Point(90,73);
                    break;
                case 5:
                    btn_8.Location = new Point(180,73);
                    break;
                case 6:
                    btn_8.Location = new Point(1,143);
                    break;
                case 7:
                    btn_8.Location = new Point(90,143);
                    break;
                case 8:
                    btn_8.Location = new Point(180,143);
                    break;
                default:
                    btn_8.Location = new Point(90,143);
                    break;
            }
            switch (_rd9)
            {
                case 0:
                    btn_free.Location = new Point(1,3);
                    break;
                case 1:
                    btn_free.Location = new Point(90,3);
                    break;
                case 2:
                    btn_free.Location = new Point(180,3);
                    break;
                case 3:
                    btn_free.Location = new Point(1,73);
                    break;
                case 4:
                    btn_free.Location = new Point(90,73);
                    break;
                case 5:
                    btn_free.Location = new Point(180,73);
                    break;
                case 6:
                    btn_free.Location = new Point(1,143);
                    break;
                case 7:
                    btn_free.Location = new Point(90,143);
                    break;
                case 8:
                    btn_free.Location = new Point(180,143);
                    break;
                default:
                    btn_free.Location = new Point(180, 143);
                    break;
            }
            str();

        }
        int second = 0;
        int Minute = 0;
        int hour = 0;
        private void tmr_time_Tick(object sender, EventArgs e)
        {  //برنامه نویس بهروز نوبهار nobahar.behrooz@gmail.com
            second++;
            if(second == 60)
            {
                second = 0;
                Minute++;
                if (Minute == 60)
                    Minute = 0;
                   hour++;
            }
            label34.Text = second.ToString();
            label35.Text = Minute.ToString();
            label36.Text = hour.ToString();

        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            Boolean startflag = false;
            if (_1x == 1 && _1y == 3)
            if (_2x == 90 && _2y == 3)
            if (_3x == 180 && _3y == 3)
            if (_4x == 1 && _4y == 73)
            if (_5x == 90 && _5y == 73)
            if (_6x == 180 && _6y == 73)
            if (_7x == 1 && _7y == 143)
            if (_8x == 90 && _8y == 143)
            { tmr_time.Stop();
              startflag = true;
              MessageBox.Show("is sorted puzell.", ":)");
            }
            if (startflag==false)
            { label22.ResetText();
              tmr_time.Start();
              harekat = 1;
              label34.ResetText();
              label35.ResetText();
              label36.ResetText();
              second = 0;
              Minute = 0;
              hour = 0;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }
        private void btn_hiurestik_Click(object sender, EventArgs e)
        {
            hiorestik();
        }
    }
}
//برنامه نویس بهروز نوبهار nobahar.behrooz@gmail.com